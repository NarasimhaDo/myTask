//
//  CustomTableViewCell.h
//  LeLabTask
//
//  Created by narasimhudu Duvvuru on 08/04/20.
//  Copyright © 2020 narasimhudu Duvvuru. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LelabContstsnts.h"

NS_ASSUME_NONNULL_BEGIN

@interface CustomTableViewCell : UITableViewCell

@property (nonatomic,retain) UILabel *title_label;
@property (nonatomic,retain) UILabel *mobile_label;
@property (nonatomic,retain) UIView *separator;
-(void)showTableviewCell:(NSMutableDictionary *)details;
@end

NS_ASSUME_NONNULL_END
