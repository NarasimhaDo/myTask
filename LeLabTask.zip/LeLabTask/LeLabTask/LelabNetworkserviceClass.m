//
//  LelabNetworkserviceClass.m
//  LeLabTask
//
//  Created by narasimhudu Duvvuru on 08/04/20.
//  Copyright © 2020 narasimhudu Duvvuru. All rights reserved.
//

#import "LelabNetworkserviceClass.h"

@implementation LelabNetworkserviceClass

// fetch data from server
-(void)networkserviceGetMethodCalll:(NSString *)ulrstring Withtype:(NSString *)type
{
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setHTTPMethod:type];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"accept"];
    [request setValue:auth_key forHTTPHeaderField:@"Authorization"];
    [request setURL:[NSURL URLWithString:ulrstring]];

    [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:
      ^(NSData * _Nullable data,
        NSURLResponse * _Nullable response,
        NSError * _Nullable error) {
        NSLog(@"erro%@",[error description]);
        if ([ulrstring containsString:@"/contact/v1/lis"]) {
            NSString *charlieSendString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                  NSLog(@"the data is %@",charlieSendString);
        }
        if ([error code] == -1005) {
            //network connection failure
            if (self->_NetworkServiceBlock!=nil) {
                self.NetworkServiceBlock(@{
                    @"Data"                                       : @"no"},Diconnect);
            }
            return;
        }
        else if ([error code] == -999) {
            // @"Please Try   again"
            return;
        }
        else if ([error code] == -1009) {
            //@"internet connection not avilable"
            if (self->_NetworkServiceBlock!=nil) {
                self.NetworkServiceBlock(@{
                    @"Data"                                       : @"no"},noInternet);
            }
            return;
        }
        else if ([error code] == -1001) {
            //@"connection timed out"
            if (self->_NetworkServiceBlock!=nil) {
                self.NetworkServiceBlock(@{
                    @"Data"                                       : @"no"},TimeUp);
            }
            return;
        }
        else
        {
            if (data != nil) {
                @try{
                    [self recivingJSONData:data withError:error];
                }@catch(NSException *exception){
//                    NSLog(@"the exception is %@",exception.reason);
                }
            }
        }
    }] resume];
}

-(void)recivingJSONData:(NSData *)data withError:(NSError *)error
{
    @try{
        NSMutableArray *jsonResponse =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
       
        if (_NetworkServiceBlock!=nil && jsonResponse.count !=0) {
            self.NetworkServiceBlock(jsonResponse,success_key);
        }
        else
        {
             self.NetworkServiceBlock(jsonResponse,NoSuccess);
        }
        return;
        
    }@catch(NSException *exception){
    }
}


-(void)NetworkServiceCompleted:(nullable NetworkCompletioHandlerAction)completionHandler
{
    self.NetworkServiceBlock = completionHandler;
}


@end
