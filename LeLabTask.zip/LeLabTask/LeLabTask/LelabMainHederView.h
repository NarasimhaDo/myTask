//
//  LelabMainHederView.h
//  LeLabTask
//
//  Created by narasimhudu Duvvuru on 08/04/20.
//  Copyright © 2020 narasimhudu Duvvuru. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LelabContstsnts.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^HeaderActionHadler) (NSString  * _Nullable Type);

@interface LelabMainHederView : UIView

@property (nonatomic,retain) UIView *statusBarview;
@property (nonatomic,retain) UIButton *backButton;
@property (nonatomic,retain) UILabel *profile_label;

@property(nonatomic,strong) HeaderActionHadler __block ActionBlock;
-(void)headerMenuComplitionHandler:(nullable HeaderActionHadler)ComplitionBlock;
-(void)showHeaderViewOfSuperView:(UIViewController *)superViewController withType:(NSString *)type;
-(CGFloat)getHeight;

@end

NS_ASSUME_NONNULL_END
