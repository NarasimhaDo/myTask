//
//  ViewController.m
//  LeLabTask
//
//  Created by narasimhudu Duvvuru on 07/04/20.
//  Copyright © 2020 narasimhudu Duvvuru. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    LelabMainHederView *headerView = [[LelabMainHederView alloc]initWithFrame:CGRectMake(0, 0, Max_Width, 80)];
    [headerView showHeaderViewOfSuperView:self withType:list_title_key];
    [self.view addSubview:headerView];
    
    // tableview creation
    
    _listTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, [headerView getHeight], Max_Width, Max_Height- [headerView getHeight])];
    _listTableView.delegate = self;
    _listTableView.dataSource = self;
    [self.view addSubview:_listTableView];
    
    _listArray = [[[NSUserDefaults standardUserDefaults] valueForKey:StoreContact_key] mutableCopy];
    if (_listArray.count !=0) {
        [_listTableView reloadData];
    }
    else{
         [self ActivityLoader];
    }
    
    [self  fetchDataFromServerwithUrl:fetch_url completion:^(NSMutableArray *listOfadata) {
        if (listOfadata.count !=0) {
            self->_listArray  = [listOfadata mutableCopy];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self->_listTableView reloadData];
                [self StopActivityLoader];
            });
        }
    }];

}

-(void)fetchDataFromServerwithUrl:(NSString *)url completion:(void(^)(NSMutableArray *listOfadata))completion{

    LelabNetworkserviceClass *networkObj = [[LelabNetworkserviceClass alloc]init];
    [networkObj networkserviceGetMethodCalll:url Withtype:Get_method];
    [networkObj NetworkServiceCompleted:^(NSMutableArray * _Nullable json, NSString * _Nullable outCome) {
            NSLog(@"the data is %@",json);
            if ([outCome isEqualToString:success_key]) {
                [[NSUserDefaults standardUserDefaults] setObject:json forKey:StoreContact_key];
                [[NSUserDefaults standardUserDefaults] synchronize];
                completion (json);
            }
            else {
                [LelabUtilites tostMessage:errorMessage fromViewController:self];
            }
    }];
}
#pragma mark - table view data source methods

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomTableViewCell *cell = [[CustomTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cell_identifier];
    [cell showTableviewCell:[_listArray objectAtIndex:indexPath.row]];
     
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
       cell.selectionStyle= UITableViewCellSelectionStyleNone;
    return cell;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _listArray.count;
}

#pragma mark - tabeview delegate methods

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    LelabProfileView *profileView = [[LelabProfileView alloc]initWithFrame:CGRectMake(0, 0, Max_Width, Max_Height)];
    [profileView showuserInfoView:[_listArray objectAtIndex:indexPath.row] withController:self];
    [self.view addSubview:profileView];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return tablevviewCell_height;
}

#pragma mark - Activity Loaders
-(void)ActivityLoader
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [self->_ActivityView removeFromSuperview];
        
        self->_ActivityView=[[UIView alloc] initWithFrame:CGRectMake(Max_Width/2-30, Max_Height/2-25, 58, 58)];
        self.ActivityView.layer.cornerRadius = self.ActivityView.frame.size.height/2;
        self.ActivityView.backgroundColor = [LelabUtilites colorWithHexString:headerColor];
        [self.view addSubview:self->_ActivityView];
        self->_activityLoaderObj= [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(0, 0, self->_ActivityView.frame.size.width, self->_ActivityView.frame.size.height)];
        [self->_activityLoaderObj setColor:[UIColor whiteColor]];
        [self->_activityLoaderObj startAnimating];
        self->_activityLoaderObj.hidesWhenStopped = YES;
        [self->_ActivityView addSubview:self->_activityLoaderObj];
    });
}

// stop activity view
-(void)StopActivityLoader
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [self->_activityLoaderObj stopAnimating];
        [self->_ActivityView removeFromSuperview];
    });
}

@end
