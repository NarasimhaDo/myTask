//
//  LelabProfileView.m
//  LeLabTask
//
//  Created by narasimhudu Duvvuru on 08/04/20.
//  Copyright © 2020 narasimhudu Duvvuru. All rights reserved.
//

#import "LelabProfileView.h"

@implementation LelabProfileView
{
    LelabMainHederView *headerview;
}
-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

-(void)showuserInfoView:(NSMutableDictionary *)dataDict withController:(UIViewController *)controller
{
    _superController = controller;
    _profileDetails = dataDict;
    
    headerview = [[LelabMainHederView alloc]initWithFrame:CGRectMake(0, 0, Max_Width, 80)];
    [headerview showHeaderViewOfSuperView:controller withType:info_title_key];
    [headerview headerMenuComplitionHandler:^(NSString * _Nullable Type) {
        if ([Type isEqualToString:@"back"]) {
            [self navigateback];
        }
    }];
    [self addSubview:headerview];
    
    [self showpersonalDetails];
}
-(void)navigateback
{
    [self removeFromSuperview];
}
-(void)showpersonalDetails {
    
    _background_scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, headerview.frame.size.height, Max_Width, Max_Height-(headerview.frame.size.height))];
    _background_scrollView.showsVerticalScrollIndicator = NO;
    _background_scrollView.showsHorizontalScrollIndicator = NO;
    _background_scrollView.backgroundColor = [LelabUtilites colorWithHexString:@"fafafa"];
    [self addSubview:_background_scrollView];
    
    _background_layerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, Max_Width, 100)];
    _background_layerView.layer.masksToBounds = NO;
    _background_layerView.layer.shadowOffset = CGSizeMake(2, 3);
    _background_layerView.layer.shadowRadius = 3;
    _background_layerView.layer.shadowOpacity = 0.3;
    _background_layerView.layer.backgroundColor = [UIColor whiteColor].CGColor;
    _background_layerView.backgroundColor =[UIColor whiteColor];
    [_background_scrollView addSubview:_background_layerView];
    
    NSString *user_name = [_profileDetails valueForKey:user_name_key];
    height = 10;
    
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(20, 10, 25, 25)];
    imageView.image = [UIImage imageNamed:@"contact_personal_info_icon"];
    [_background_layerView addSubview:imageView];
    
    UILabel *titleLable = [[UILabel alloc]initWithFrame:CGRectMake(60, 10, Max_Width-150, 25)];
    titleLable.font = [UIFont fontWithName:poppinssemobold size:13.0];
    titleLable.text = @"PERSONAL DETAILS";
    titleLable.textColor = [LelabUtilites colorWithHexString:@"919394"];
    [_background_layerView addSubview:titleLable];
    
    CGFloat name_height = [LelabUtilites getLabelHeight:CGSizeMake(Max_Width-100, MAXFLOAT) string:user_name font:[UIFont fontWithName:poppinssemobold size:15.0]];
    _name_label = [[UILabel alloc]initWithFrame:CGRectMake(70, titleLable.frame.size.height+titleLable.frame.origin.y+10, Max_Width-90, name_height)];
    _name_label.font = [UIFont fontWithName:poppinssemobold size:15.0];
    _name_label.text = user_name;;
    _name_label.textColor = [LelabUtilites colorWithHexString:@"171312"];
    [_background_layerView addSubview:_name_label];
   
    int row_height  = _name_label.frame.size.height+_name_label.frame.origin.y+10;
    
    
    NSString *email = [_profileDetails valueForKey:email_key];
    CGFloat email_height = [LelabUtilites getLabelHeight:CGSizeMake(Max_Width-100, MAXFLOAT) string:email font:[UIFont fontWithName:poppinsRegular size:15.0]];
    _email_label = [[UILabel alloc]initWithFrame:CGRectMake(70, row_height, Max_Width-150, email_height)];
    _email_label.font = [UIFont fontWithName:poppinsRegular size:15.0];
    _email_label.text = email;;
    _email_label.textColor = [LelabUtilites colorWithHexString:@"171312"];
    [_background_layerView addSubview:_email_label];
    
    _email_button = [[UIButton alloc]initWithFrame:CGRectMake(Max_Width-60, row_height-3, 30, 30)];
    [_email_button setImage:[UIImage imageNamed:@"contact_email_icon"] forState:UIControlStateNormal];
    [_email_button addTarget:self action:@selector(sentEmailAction:) forControlEvents:UIControlEventTouchUpInside];
    [_email_button setTitle:email forState:UIControlStateNormal];
    [_email_button setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [_background_layerView addSubview:_email_button];
    
    row_height  = _email_label.frame.size.height+_email_label.frame.origin.y+10;
    
    
    NSString *phone = [_profileDetails valueForKey:phone_key];
    CGFloat phone_height = [LelabUtilites getLabelHeight:CGSizeMake(Max_Width-100, MAXFLOAT) string:phone font:[UIFont fontWithName:poppinsRegular size:15.0]];
    _phone_label = [[UILabel alloc]initWithFrame:CGRectMake(70, row_height, Max_Width-90, phone_height)];
    _phone_label.font = [UIFont fontWithName:poppinsRegular size:15.0];
    _phone_label.text = phone;;
    _phone_label.textColor = [LelabUtilites colorWithHexString:@"171312"];
    [_background_layerView addSubview:_phone_label];
    
    _phone_button = [[UIButton alloc]initWithFrame:CGRectMake(Max_Width-60, row_height-3, 30, 30)];
    [_phone_button setImage:[UIImage imageNamed:@"contact_call_active_icon"] forState:UIControlStateNormal];
    [_phone_button addTarget:self action:@selector(calltoUser:) forControlEvents:UIControlEventTouchUpInside];
    [_phone_button setTitle:phone forState:UIControlStateNormal];
    [_phone_button setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [_background_layerView addSubview:_phone_button];
    
    row_height  = _phone_label.frame.size.height+_phone_label.frame.origin.y+10;
    
    UIImageView *company_imageView = [[UIImageView alloc]initWithFrame:CGRectMake(20, row_height, 25, 25)];
    company_imageView.image = [UIImage imageNamed:@"contact_company_icon"];
    [_background_layerView addSubview:company_imageView];
    
    UILabel *company_titleLable = [[UILabel alloc]initWithFrame:CGRectMake(60, row_height, Max_Width-150, 25)];
    company_titleLable.font = [UIFont fontWithName:poppinssemobold size:13.0];
    company_titleLable.text = @"COMPANY DETAILS";
    company_titleLable.textColor = [LelabUtilites colorWithHexString:@"919394"];
    [_background_layerView addSubview:company_titleLable];
    
     row_height  = row_height + 30;
    
    NSString *company = [[_profileDetails valueForKey:company_key] valueForKey:name_key];
    CGFloat company_height = [LelabUtilites getLabelHeight:CGSizeMake(Max_Width-100, MAXFLOAT) string:company font:[UIFont fontWithName:poppinssemobold size:15.0]];
    _company_label = [[UILabel alloc]initWithFrame:CGRectMake(70, row_height, Max_Width-90, company_height)];
    _company_label.font = [UIFont fontWithName:poppinssemobold size:15.0];
    _company_label.text = company;;
    _company_label.textColor = [LelabUtilites colorWithHexString:@"171312"];
    [_background_layerView addSubview:_company_label];

    row_height  = _company_label.frame.size.height+_company_label.frame.origin.y+10;

    NSString *website = [_profileDetails valueForKey:website_key];
    CGFloat website_height = [LelabUtilites getLabelHeight:CGSizeMake(Max_Width-100, MAXFLOAT) string:website font:[UIFont fontWithName:poppinsRegular size:15.0]];
    _website_label = [[UILabel alloc]initWithFrame:CGRectMake(70,row_height, Max_Width-90, website_height)];
    _website_label.font = [UIFont fontWithName:poppinsRegular size:15.0];
    _website_label.text = website;;
    _website_label.textColor = [LelabUtilites colorWithHexString:@"171312"];
    [_background_layerView addSubview:_website_label];
    
    row_height  = _website_label.frame.size.height+_website_label.frame.origin.y+10;
    
    
    UIImageView *address_imageView = [[UIImageView alloc]initWithFrame:CGRectMake(20, row_height, 25, 25)];
    address_imageView.image = [UIImage imageNamed:@"contact_address_icon"];
    [_background_layerView addSubview:address_imageView];

    UILabel *address_title_label = [[UILabel alloc]initWithFrame:CGRectMake(60, row_height, Max_Width-150, 25)];
    address_title_label.font = [UIFont fontWithName:poppinssemobold size:13.0];
    address_title_label.text = @"ADDRESS DETAILS";
    address_title_label.textColor = [LelabUtilites colorWithHexString:@"919394"];
    [_background_layerView addSubview:address_title_label];

    row_height = row_height + 30;

    NSMutableDictionary *addressDict = [[_profileDetails valueForKey:address_key] mutableCopy];
//
    NSString *address = [addressDict valueForKey:street_key];
    address = [NSString stringWithFormat:@"%@, %@",address, [addressDict valueForKey:suite_key]];
    address = [NSString stringWithFormat:@"%@, %@",address, [addressDict valueForKey:city_key]];
    address = [NSString stringWithFormat:@"%@, %@.",address, [addressDict valueForKey:zip_code_key]];

    CGFloat address_height = [LelabUtilites getLabelHeight:CGSizeMake(Max_Width-100, MAXFLOAT) string:address font:[UIFont fontWithName:poppinsRegular size:15.0]];
    _address_lable = [[UILabel alloc]initWithFrame:CGRectMake(70, address_title_label.frame.size.height+address_title_label.frame.origin.y+10, Max_Width-90, address_height)];
    _address_lable.font = [UIFont fontWithName:poppinsRegular size:15.0];
    _address_lable.text = address;
    _address_lable.numberOfLines= 0;
    _address_lable.textColor = [LelabUtilites colorWithHexString:@"171312"];
    [_background_layerView addSubview:_address_lable];
    
    row_height  = _address_lable.frame.size.height+_address_lable.frame.origin.y+10;
    
    _background_layerView.frame = CGRectMake(10, 10, Max_Width-20, row_height+10);
    
    height = height + _background_layerView.frame.size.height+_background_layerView.frame.origin.y + 30;
    _background_scrollView.contentSize = CGSizeMake(Max_Width, height);
}

-(void)calltoUser:(UIButton *)sender
{
    NSString *phNo = sender.titleLabel.text;
    [LelabUtilites callToUser:phNo];
}

-(void)sentEmailAction:(UIButton *)sender
{
    NSString *email_id = sender.titleLabel.text;
    [LelabUtilites emailToUser:email_id];
}
@end
