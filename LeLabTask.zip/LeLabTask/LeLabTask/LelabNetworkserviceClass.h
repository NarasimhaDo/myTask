//
//  LelabNetworkserviceClass.h
//  LeLabTask
//
//  Created by narasimhudu Duvvuru on 08/04/20.
//  Copyright © 2020 narasimhudu Duvvuru. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LelabContstsnts.h"

NS_ASSUME_NONNULL_BEGIN
typedef void (^NetworkCompletioHandlerAction) (NSMutableArray  * _Nullable json, NSString * _Nullable outCome);

@interface LelabNetworkserviceClass : NSObject

-(void)NetworkServiceCompleted:(nullable NetworkCompletioHandlerAction)completionHandler;
@property (nonatomic,copy) NetworkCompletioHandlerAction NetworkServiceBlock;
-(void)networkserviceGetMethodCalll:(NSString *)ulrstring Withtype:(NSString *)type;

@end

NS_ASSUME_NONNULL_END
