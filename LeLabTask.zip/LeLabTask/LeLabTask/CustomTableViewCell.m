//
//  CustomTableViewCell.m
//  LeLabTask
//
//  Created by narasimhudu Duvvuru on 08/04/20.
//  Copyright © 2020 narasimhudu Duvvuru. All rights reserved.
//

#import "CustomTableViewCell.h"

@implementation CustomTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)showTableviewCell:(NSMutableDictionary *)details
{
    _title_label = [[UILabel alloc]initWithFrame:CGRectMake(30, 10, Max_Width-60, 25)];
    [self addSubview:_title_label];
    _title_label.text = [details valueForKey:user_name_key];
    _title_label.textColor = [LelabUtilites colorWithHexString:@"181414"];
    _title_label.font = [UIFont fontWithName:poppinssemobold size:14];
    
    _mobile_label = [[UILabel alloc]initWithFrame:CGRectMake(30, _title_label.frame.size.height+_title_label.frame.origin.y, Max_Width-150, 25)];
    [self addSubview:_title_label];
    _mobile_label.textColor = [LelabUtilites colorWithHexString:@"868686"];
    _mobile_label.font = [UIFont fontWithName:poppinsRegular size:14];
    _mobile_label.text = [details valueForKey:phone_key];
    [self addSubview:_mobile_label];
    
    _separator = [[UIView alloc]init];
    _separator.frame = CGRectMake(10, tablevviewCell_height-1, Max_Width-20, 1);
    _separator.backgroundColor = [LelabUtilites colorWithHexString:@"e4e3e3"];
    [self addSubview:_separator];

}

@end
