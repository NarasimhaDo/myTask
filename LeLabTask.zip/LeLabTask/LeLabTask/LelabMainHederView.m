//
//  LelabMainHederView.m
//  LeLabTask
//
//  Created by narasimhudu Duvvuru on 08/04/20.
//  Copyright © 2020 narasimhudu Duvvuru. All rights reserved.
//

#import "LelabMainHederView.h"

@implementation LelabMainHederView

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}

-(void)showHeaderViewOfSuperView:(UIViewController *)superViewController withType:(NSString *)type
{
    _statusBarview = [[UIView alloc]initWithFrame:CGRectMake(0,0, Max_Width, 80)];
    _statusBarview.backgroundColor = [LelabUtilites colorWithHexString:headerColor];
    [self addSubview:_statusBarview];
    
    _backButton  = [[UIButton alloc]initWithFrame:CGRectMake(0, 30, 40, 40)];
    [_backButton setImage:[UIImage imageNamed:@"leftArrow_icon"] forState:UIControlStateNormal];
    _backButton.imageEdgeInsets = UIEdgeInsetsMake(10, 10, 10, 10);
    [_backButton addTarget:self action:@selector(backNavigation:) forControlEvents:UIControlEventTouchUpInside];
    [_statusBarview addSubview:_backButton];

    _profile_label = [[UILabel alloc]initWithFrame:CGRectMake(50, 35, Max_Width-60, 30)];
    _profile_label.text = type;
    _profile_label.font = [UIFont fontWithName:poppinssemobold size:17];
    _profile_label.textColor = [UIColor whiteColor];
    [_statusBarview addSubview:_profile_label];
       
    if ([LelabUtilites chekIphoneNewModelOrOld]) {
        _statusBarview.frame = CGRectMake(0,0, Max_Width, 100);
        _backButton.frame = CGRectMake(0, 35, 40, 40);
        _profile_label.frame = CGRectMake(50, 40, Max_Width-60, 30);
    }
    
    if ([type isEqualToString:list_title_key]) {
        _backButton.hidden = YES;
        _profile_label.frame = CGRectMake(20, 35, Max_Width-60, 30);
        _profile_label.font = [UIFont fontWithName:poppinssemobold size:20];
        if ([LelabUtilites chekIphoneNewModelOrOld]) {
            _profile_label.frame = CGRectMake(20, 40, Max_Width-60, 30);
        }
    }
    
}

-(void)backNavigation:(UIButton *)sender
{
    self.ActionBlock(@"back");
}
-(CGFloat)getHeight
{
    return _statusBarview.frame.size.height+_statusBarview.frame.origin.y;
}
-(void)headerMenuComplitionHandler:(HeaderActionHadler)ComplitionBlock
{
    self.ActionBlock = ComplitionBlock;
}

@end
